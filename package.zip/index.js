const fs = require('fs');
const MongoClient = require("mongodb").MongoClient;

const MONGODB_URI = "mongodb+srv://konectify_admin:Konectify2022@konectifyshops.e3t1n.mongodb.net/?retryWrites=true&w=majority";

let Db = null;

async function connectToDatabase() {
    if (cachedDb) {
      return cachedDb;
    }
  
    // Connect to our MongoDB database hosted on MongoDB Atlas
    const client = await MongoClient.connect(MONGODB_URI);
  
    // Specify which database we want to use
    const db = await client.db("livealtoDB");
  
    cachedDb = db;
    return db;
}

exports.handler = async (event, context) => {

    if(event.body == null || event.body == undefined){
        return 'no callback data detected'
    }
    /* By default, the callback waits until the runtime event loop is empty before freezing the process and returning the results to the caller. Setting this property to false requests that AWS Lambda freeze the process soon after the callback is invoked, even if there are events in the event loop. AWS Lambda will freeze the process, any state data, and the events in the event loop. Any remaining events in the event loop are processed when the Lambda function is next invoked, if AWS Lambda chooses to use the frozen process. */
    context.callbackWaitsForEmptyEventLoop = false;
    const body = JSON.parse(event.body)
    const currentTime = new Date().toLocaleString();
    const callbackData = `[${currentTime}]\n${JSON.stringify(body)}\n\n`;
    fs.appendFileSync('http://localhost:4000/mpesa_callback.txt', callbackData);
    // Get an instance of our database
    const db = await connectToDatabase();
    const params = {
        MerchantRequestID: body.Body.stkCallback.MerchantRequestID, 
        CheckoutRequestID:body.Body.stkCallback.CheckoutRequestID, 
        ResultCode: body.Body.stkCallback.ResultCode, 
        ResultDesc:body.Body.stkCallback.ResultDesc
    }
    if(body.Body.stkCallback.CallbackMetadata){
        const CallBackMetadata = {
            Amount:body.Body.stkCallback.CallBackMetadata.item[0].Value,
            PhoneNumber: body.Body.stkCallback.CallBackMetadata.item[4].Value,
            TransactionID:body.Body.stkCallback.CallBackMetadata.item[2].Value,
            TransactionDate:new Date(body.Body.stkCallback.CallBackMetadata.item[3].Value)
        }
        params.MetaData = CallBackMetadata
    }
    // Make a MongoDB MQL Query to go into the movies collection and return the first 20 movies.
    const insert = await db.collection("MpesaTable").insertOne(params);
  
    const response = {
      statusCode: 200,
      body: JSON.stringify('data upload success'),
    };
  
    return response;
  };